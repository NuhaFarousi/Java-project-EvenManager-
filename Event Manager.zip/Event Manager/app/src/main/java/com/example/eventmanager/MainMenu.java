package com.example.eventmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainMenu extends AppCompatActivity  implements View.OnClickListener {
    CardView allevents,createevent,searchevent,exit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        allevents=findViewById(R.id.crd_all_events);
        createevent=findViewById(R.id.crd_crt_evnt);
        searchevent=findViewById(R.id.crd_search);
        exit=findViewById(R.id.crd_ext);
        allevents.setOnClickListener(this);
        createevent.setOnClickListener(this);
        searchevent.setOnClickListener(this);
        exit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v==exit){
            ActivityCompat.finishAffinity(MainMenu.this);
        }
        else
        if(v==allevents) {
            startActivity(new Intent(MainMenu.this,allevents.class));
        }
        else
        if(v==createevent) {
            startActivity(new Intent(MainMenu.this,create.class));
        }
        else
        if(v==searchevent) {
            startActivity(new Intent(MainMenu.this,Search.class));
        }
    }
}
