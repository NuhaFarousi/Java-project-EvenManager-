package com.example.eventmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Sign_up extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        final AutoCompleteTextView Email=findViewById(R.id.editText2);
        final EditText Password=findViewById(R.id.editText);
        final EditText CPassword=findViewById(R.id.editText_2);
        Button btnCreateAccount=findViewById(R.id.btncreateaccount);
        btnCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Email.setError(null);
                Password.setError(null);
                if(TextUtils.isEmpty(Email.getText())) {
                    Email.setError("This Field Is Required..");
                    Email.requestFocus();
                    return;
                }

                if(TextUtils.isEmpty(Password.getText())) {
                    Password.setError("This Field Is Required..");
                    Password.requestFocus();
                    return;
                }

                if(TextUtils.isEmpty(CPassword.getText())) {
                    CPassword.setError("This Field Is Required..");
                    CPassword.requestFocus();
                    return;
                }

                if(!Password.getText().toString().equals(CPassword.getText().toString())) {
                    CPassword.setError("Password Miss-Match");
                    CPassword.requestFocus();
                    return;
                }

                createEmailPass(Email.getText().toString().replaceAll(" ",""),Password.getText().toString());
            }
        });
    }

    public  void showMessage(String Message,String Title) {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle(Title);
        alert.setMessage(Message);
        alert.setPositiveButton("OK",null);
        alert.show();
    }

    private void createEmailPass(String Email, String Password) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Creating Account..");
        progressDialog.setCancelable(false);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(Email,Password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressDialog.dismiss();
                        if (task.isSuccessful()) {
                            showMessage("Account Created Successfully..","Success");
                            sendVerificationEmail();
                        }
                        else
                        {
                            showMessage(task.getException().getMessage(),"Error");
                        }
                    }
                });
    }

    private void sendVerificationEmail() {
        Toast.makeText(this,"Sending Verification Link..",Toast.LENGTH_LONG).show();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if(user!=null)
            user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(Sign_up.this,"Verification Link Has Been Sent To the Email Please Open Your Email And Verify ",Toast.LENGTH_LONG).show();
                        FirebaseAuth.getInstance().signOut();
                    }
                    else
                    {
                        Toast.makeText(Sign_up.this,task.getException().getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
            });
    }
}
