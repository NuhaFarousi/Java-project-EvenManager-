package com.example.eventmanager;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class eventsadapter  extends BaseAdapter {
    ArrayList<eventsmodelclass> events;
    Context context;
    public eventsadapter(Context context, ArrayList<eventsmodelclass>  events) {
        this.context=context;
        this.events=events;
    }

    @Override
    public int getCount() {
        return events.size();
    }

    @Override
    public Object getItem(int position) {
        return events.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public int getViewTypeCount() {
        return getCount();
    }

    @Override
    public int getItemViewType(int position)
    {
        return position;
    }

    @NonNull

    @Override
    public View getView(final int position, View convertView, @NonNull ViewGroup parent) {
        eventsmodelclass event = events.get(position);
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        @SuppressLint("ViewHolder")
        View row = inflater.inflate(R.layout.lyt_event, parent, false);
        TextView Date=row.findViewById(R.id.event_date);
        TextView Location=row.findViewById(R.id.event_location);
        TextView Title=row.findViewById(R.id.event_title);
        ImageView img=row.findViewById(R.id.event_img);
        CardView event_parent=row.findViewById(R.id.event_parent);
        event_parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eventdetail.event=events.get(position);
                getContext().startActivity(new Intent(getContext(),eventdetail.class));
            }
        });

        Date.setText(event.getDate());
        Location.setText(event.getLOCATION());
        Title.setText(event.getTITLE());
        Picasso.get().load(event.getImage_URL()).placeholder(getContext().getDrawable(R.drawable.spiner)).into(img);
        return row;
    }

    private Context getContext() {
        return this.context;
    }
}
