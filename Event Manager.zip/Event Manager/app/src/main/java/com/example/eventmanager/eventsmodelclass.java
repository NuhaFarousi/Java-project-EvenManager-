package com.example.eventmanager;

public class eventsmodelclass {
    private String TITLE;
    private String LOCATION;
    private String Date;
    private String DESCRIPTION;
    private String RATING;

    public String getKEY() {
        return KEY;
    }

    public void setKEY(String KEY) {
        this.KEY = KEY;
    }

    private String KEY;
    public String getTITLE() {
        return TITLE;
    }
    public void setTITLE(String TITLE) {
        this.TITLE = TITLE;
    }
    public String getLOCATION() {
        return LOCATION;
    }
    public void setLOCATION(String LOCATION) {
        this.LOCATION = LOCATION;
    }
    public String getDate() {
        return Date;
    }
    public void setDate(String date) {
        Date = date;
    }
    public String getDESCRIPTION() {
        return DESCRIPTION;
    }
    public void setDESCRIPTION(String DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }
    public String getRATING() {
        return RATING;
    }
    public void setRATING(String RATING) {
        this.RATING = RATING;
    }
    public String getImage_URL() {
        return Image_URL;
    }
    public void setImage_URL(String image_URL) {
        Image_URL = image_URL;
    }
    private String Image_URL;
}
