package com.example.eventmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class log_in extends AppCompatActivity {
        Button login;
        EditText Password;
        AutoCompleteTextView Name;
        TextView createaccounttext;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_log_in);
                login=findViewById(R.id.Login);
                Name=findViewById(R.id.editText2);
                Password=findViewById(R.id.editText);
                TextView ForgetPass=findViewById(R.id.passwordreset);
                createaccounttext=findViewById(R.id.createaccount);
                SpannableString content=new SpannableString("Forget Password");
                content.setSpan(new UnderlineSpan(),0,content.length(),0);
                ForgetPass.setText(content);
                FirebaseApp.initializeApp(log_in.this);
                FirebaseAuth.getInstance().signOut();
                createaccounttext.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View v){
                createaccount();
                }
                });
                login.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view){

                if(FirebaseAuth.getInstance().getCurrentUser()!=null)
                FirebaseAuth.getInstance().signOut();
                Name.setError(null);
                Password.setError(null);

                if(TextUtils.isEmpty(Name.getText().toString())){
                Name.setError("This Field Is Required");
                Name.setError("This Field Is Required");
                Name.requestFocus();
                return;
                }

                if(TextUtils.isEmpty(Password.getText().toString())){
                Password.setError("This Field Is Required");
                Password.requestFocus();
                return;
                }

                VerifyEmailAndPass(Name.getText().toString().replaceAll(" ",""),Password.getText().toString());
                }
                });

                ForgetPass.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view){
                prompforEmail();
                }
                });
                }

        private void createaccount()
                {
                startActivity(new Intent(log_in.this,Sign_up.class));
                }

        public  void prompforEmail() {

        final AlertDialog.Builder alert=new AlertDialog.Builder(this);
                LinearLayout layout=new LinearLayout(log_in.this);
                layout.setOrientation(LinearLayout.VERTICAL);
                layout.setPadding(30,20,30,20);
                LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
                );
                params.setMargins(0,20,0,0);

        final EditText edittext=new EditText(this);

        final TextView Title=new TextView(this);
                edittext.setHint("Enter Your Email");
                edittext.setAlpha(0.6f);
                edittext.setLayoutParams(params);
                Title.setText("Password Reset");
                Title.setAlpha(0.9f);
                Title.setTypeface(Typeface.SERIF);
                Title.setTextSize(18f);
                layout.addView(Title);
                layout.addView(edittext);
                alert.setView(layout);
                alert.setPositiveButton("Done",new DialogInterface.OnClickListener(){
        @Override
        public void onClick(DialogInterface dialog,int whichButton){
                edittext.setError(null);

        final ProgressDialog progressDialog=new ProgressDialog(log_in.this);
                progressDialog.setMessage("Sending Password Reset Link...");
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressDialog.show();

                if(TextUtils.isEmpty(edittext.getText().toString())){
                edittext.setError("This Field is Required");
                edittext.requestFocus();
                return;
                }

                // AlertDialog progressDialog = general.dialogLoading(Main.this,"Jus A Second | Sending link To Reset Password");
                FirebaseAuth.getInstance().sendPasswordResetEmail(edittext.getText().toString())
                .addOnCompleteListener(new OnCompleteListener<Void>(){
        @Override
        public void onComplete(@NonNull Task<Void> task)
                {

                try{
                progressDialog.dismiss();
                if(task.isSuccessful()) {
                showMessage("Password Reset Link Has Been Sent To Your Email Address","Linl Sent");
                }
                else
                {
                showMessage(task.getException().getMessage(),"Error");
                }
                }catch(Exception ignored){
                }
                }
                });

                }
                });
                alert.setNegativeButton("Dismiss",new DialogInterface.OnClickListener(){
        @Override
        public void onClick(DialogInterface dialog,int whichButton){
                // DO Nothing
                }
                });
                alert.show();
                }
                void VerifyEmailAndPass(final String Email,String Password){

        final ProgressDialog progressDialog=new ProgressDialog(this);
                progressDialog.setMessage("Logging In...");
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressDialog.show();
                FirebaseAuth.getInstance().signInWithEmailAndPassword(Email,Password).addOnCompleteListener(new OnCompleteListener<AuthResult>(){
        @Override
        public void onComplete(@NonNull Task<AuthResult> task)
                {
                progressDialog.dismiss();

                if(task.isSuccessful()) {
                FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();

                if(user!=null) {

                if(user.isEmailVerified()) {
                sigIn(Email);
                }
                else
                {
                AskToVerify(Email);
                }
                }
                else
                {
                showMessage("Unexpected Error Occured","Error");
                }
                }
                else
                {
                showMessage(task.getException().getMessage(),"Error");
                }
                }
                });
                }
        public void AskToVerify(String Email) {
                try{
                AlertDialog.Builder builder=new AlertDialog.Builder(log_in.this);
                builder.setTitle("Pending Verification");
                builder.setCancelable(false);
                builder.setMessage("Your Email : "+Email+" Is Not Verified Please Open Your Email And Click On Verification Link To  Verify....");
                builder.setNegativeButton("Resend Verification Link",new DialogInterface.OnClickListener(){
        @Override
        public void onClick(DialogInterface dialog,int which){
                sendVerificationEmail();
                }
                });
                builder.setPositiveButton("OK",null);
                AlertDialog dialog=builder.create();
                dialog.show();
                }
                catch(Exception e)
                {
                e.printStackTrace();
                }
                }
        private void sendVerificationEmail() {
        final ProgressDialog progressDialog=new ProgressDialog(this);
                progressDialog.setMessage("Sending Verification Link...");
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressDialog.show();
                FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();

                if(user!=null)
                user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>(){
        @Override
        public void onComplete(@NonNull Task<Void> task){
                progressDialog.dismiss();

                if(task.isSuccessful()){
                Toast.makeText(getApplicationContext(),"Verification Link Has Been Sent To Your Email Please Open Your Email And Verify ",Toast.LENGTH_LONG).show();
                FirebaseAuth.getInstance().signOut();
                }
                else
                {
                Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_LONG).show();
                }
                }
                });
                }
        private void sigIn(String email){
                finish();
                startActivity(new Intent(log_in.this,MainMenu.class).putExtra("userEmail",email));
                }
        public  void showMessage(String Message,String Title) {
                AlertDialog.Builder alert=new AlertDialog.Builder(log_in.this);
                alert.setTitle(Title);
                alert.setMessage(Message);
                alert.setPositiveButton("OK",null);
                alert.show();
                }
        }

