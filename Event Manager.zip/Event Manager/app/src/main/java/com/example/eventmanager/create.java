package com.example.eventmanager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class create extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    EditText titleedtxt;
    EditText location_edtxt;
    TextView date_edtxt;
    EditText description_edtxt;
    ImageView imageView;
    RatingBar ratingBar;
    String firebaseimg;
    Uri mImageUri;
    Button create_btn;
    StorageReference mstoragerefrence;
    final Calendar myCalendar = Calendar.getInstance();
    static eventsmodelclass event;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        titleedtxt=findViewById(R.id.title_edtxt);
        imageView=findViewById(R.id.imageView);
        create_btn=findViewById(R.id.create_btn);
        description_edtxt=findViewById(R.id.Desription_edtxt);
        date_edtxt=findViewById(R.id.date_edtxt);
        location_edtxt=findViewById(R.id.location_edtxt);
        ratingBar=findViewById(R.id.ratingBar);
        mstoragerefrence= FirebaseStorage.getInstance().getReference("Events");
        create_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validate()) {
                    uploadfile();
                }
            }
        });

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                setDate();
            }

        };

        date_edtxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                new DatePickerDialog(create.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openchosefile();

            }
        });
        setDate();
        isEdit();
    }

    private void isEdit(){
    if(event!=null) {
        Picasso.get().load(event.getImage_URL()).fit().into(imageView);
        titleedtxt.setText(event.getTITLE());
        description_edtxt.setText(event.getDESCRIPTION());
        date_edtxt.setText(event.getDate());
        location_edtxt.setText(event.getLOCATION());
        ratingBar.setRating(Float.parseFloat(event.getRATING()));
    }
    }

    private void setDate() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        date_edtxt.setText(sdf.format(myCalendar.getTime()));
    }

    public void openchosefile() {
        Intent intent=new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,PICK_IMAGE_REQUEST);
    }

    private String getFileextension(Uri uri){
        ContentResolver cr=getContentResolver();
        MimeTypeMap mime=MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(uri));
    }

    private void uploadfile(){

        if(mImageUri!=null || event!=null) {
            if(mImageUri!=null) {
            StorageReference filerefrence=mstoragerefrence.child(System.currentTimeMillis()+"."+getFileextension(mImageUri));
            final ProgressDialog mDialog = new ProgressDialog(create.this);
            mDialog.setMessage("PLEASE WAIT...");
            mDialog.show();

                filerefrence.putFile(mImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        firebaseimg = taskSnapshot.getDownloadUrl().toString();
                        upload_post_data();
                        mDialog.dismiss();
                    }
                }).addOnFailureListener(new OnFailureListener() {

                    @Override
                    public void onFailure(@NonNull Exception e) {
                    }
                });
            }
            else
            {
                firebaseimg = event.getImage_URL();
                upload_post_data();
            }
        }
        else
        {
            Toast.makeText(this,"NO FILE SELECTED",Toast.LENGTH_SHORT).show();
        }
    }

    public void upload_post_data(){
        final ProgressDialog mDialog = new ProgressDialog(create.this);
        mDialog.setMessage("PLEASE WAIT...");
        mDialog.show();

        eventsmodelclass obj=new eventsmodelclass();
        obj.setTITLE(titleedtxt.getText().toString());
        obj.setLOCATION(String.valueOf(location_edtxt.getText()));
        obj.setDate(String.valueOf(date_edtxt.getText()));
        obj.setDESCRIPTION(String.valueOf(description_edtxt.getText()));
        obj.setRATING(String.valueOf(ratingBar.getRating()));
        obj.setImage_URL(String.valueOf(firebaseimg));
        String KEY;
        if(event!=null) {
            KEY=event.getKEY();
        }
         else
        {
            KEY=FirebaseDatabase.getInstance().getReference("Events").push().getKey();
        }
        obj.setKEY(KEY);
        FirebaseDatabase.getInstance().getReference("Events").child(KEY).setValue(obj).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task)
            {

                mDialog.dismiss();
                if(task.isSuccessful())
                {
                    if(event==null) {
                        showDialog("Success","Successfully Created Event");
                    }
                    else
                        {
                            showDialog("Success","Event Edited Successfully");
                       }
                }
                else
                {
                    showDialog("Error","Failed To Create Event \n Cause : "+task.getException().getMessage());
                }
            }
        });
    }

    public boolean validate() {

        //LOOP ON EVERY EDITTEXT FIELD
       for(EditText fields:new EditText[]{titleedtxt,location_edtxt,description_edtxt}) {

           //IF ANY FIELD IS EMPTY
           if(TextUtils.isEmpty(fields.getText())){
               fields.setError("Required Field"); //SET ERROR
               fields.requestFocus();
               return false;
           }
       }
        //IF NO REQUIRED FIELD IS EMPTY
       return true;
    }

    public  void showDialog(String Title,String Message)
    {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        View child = getLayoutInflater().inflate(R.layout.dialog_custom, null);
        TextView title=child.findViewById(R.id.txtView_title);
        TextView message=child.findViewById(R.id.txtView_message);
        Button btn_action=child.findViewById(R.id.btn_ok);
        title.setText(Title);
        message.setText(Message);
        btn_action.setText("Ok");
        builder1.setView(child);
        builder1.setCancelable(true);
        final AlertDialog dialog = builder1.create();
        dialog.show();
        btn_action.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==PICK_IMAGE_REQUEST&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null) {
            mImageUri=data.getData();
            Picasso.get().load(mImageUri).fit().into(imageView);
        }
    }

    @Override
    protected void onDestroy() {
        event=null;
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        ActivityCompat.finishAffinity(create.this);
        startActivity(new Intent(create.this,MainMenu.class));
        super.onBackPressed();
    }
}
