package com.example.eventmanager;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import com.squareup.picasso.Picasso;

public class eventdetail extends AppCompatActivity {
    static eventsmodelclass event;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventdetail);
        TextView Date=findViewById(R.id.event_date);
        TextView Location=findViewById(R.id.event_location);
        TextView Title=findViewById(R.id.event_title);
        TextView Descrption=findViewById(R.id.event_disc);
        RatingBar Rating=findViewById(R.id.event_rating);
        ImageView img=findViewById(R.id.event_img);
        ImageView edit=findViewById(R.id.event_edit);
        Button back=findViewById(R.id.btnback);
        Date.setText(event.getDate());
        Descrption.setText(event.getDESCRIPTION());
	   Location.setText(event.getLOCATION());
        Title.setText(event.getTITLE());
        Rating.setRating(Float.parseFloat(event.getRATING()));
        Picasso.get().load(event.getImage_URL()).placeholder(getDrawable(R.drawable.spiner)).into(img);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                create.event=event;
                startActivity(new Intent(getApplicationContext(),create.class));
            }
        });
    }
}
