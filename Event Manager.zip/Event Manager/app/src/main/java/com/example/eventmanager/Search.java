package com.example.eventmanager;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class Search extends AppCompatActivity {
    EditText title,location;
    TextView txtdate;
    Button search,back;
    final Calendar myCalendar = Calendar.getInstance();
    ArrayList<eventsmodelclass> events=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        title=findViewById(R.id.editText4);
        location=findViewById(R.id.editText5);
        txtdate=findViewById(R.id.editText7);
        search=findViewById(R.id.button4);
        back=findViewById(R.id.button3);

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                setDate();
            }

        };

        txtdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(Search.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                getevents();
            }
        });
    }


    private void getevents() {
        events.clear();
        final ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Loading Events..");
        progressDialog.setCancelable(false);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();

        FirebaseDatabase.getInstance().getReference("Events").addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot childs:dataSnapshot.getChildren()) {
                    eventsmodelclass value = childs.getValue(eventsmodelclass.class);
                    if (txtdate.getText().equals("Select Date")) {
                        txtdate.setText("");
                    }
                    if(value.getDate().contains(txtdate.getText())) {
                        if( value.getTITLE().toLowerCase().contains(title.getText().toString().toLowerCase()))
                        {
                            if(value.getLOCATION().toLowerCase().contains(location.getText().toString().toLowerCase())) {
                                events.add(value);
                            }
                        }
                    }
                }

                progressDialog.dismiss();
                if(events.size()<1) {
                    showDialog("Empty","No Event Found ");
                }
                else
                {
                    setContentView(R.layout.activity_allevents);
                    GridView events_grid=findViewById(R.id.events_grid);
                    eventsadapter adapter=new eventsadapter(Search.this,events);
                    events_grid.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                showDialog("Error","Something Went Wrong \n Cause : "+databaseError.getMessage());
            }
        });
    }

    private void setDate() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        txtdate.setText(sdf.format(myCalendar.getTime()));
    }

    public  void showDialog(String Title,String Message) {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        View child = getLayoutInflater().inflate(R.layout.dialog_custom, null);
        TextView title=child.findViewById(R.id.txtView_title);
        TextView message=child.findViewById(R.id.txtView_message);
        Button btn_action=child.findViewById(R.id.btn_ok);
        title.setText(Title);
        message.setText(Message);
        btn_action.setText("Ok");
        builder1.setView(child);
        builder1.setCancelable(true);
        final AlertDialog dialog = builder1.create();
        dialog.show();
        btn_action.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();

            }
        });
    }

    @Override
    public void onBackPressed() {
        finish();
        super.onBackPressed();
    }
}
