package com.example.eventmanager;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;

public class allevents extends AppCompatActivity{
    GridView events_grid;
    ArrayList<eventsmodelclass> events=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allevents);
        events_grid=findViewById(R.id.events_grid);
        
        getevents();
    }

    private void getevents(){
        events.clear();
        final ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Loading Events..");
        progressDialog.setCancelable(false);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();

        FirebaseDatabase.getInstance().getReference("Events").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot){
                for(DataSnapshot childs:dataSnapshot.getChildren())
                {
                    eventsmodelclass value = childs.getValue(eventsmodelclass.class);
                    System.out.println(value.getDate());
                    events.add(value);
                }
                progressDialog.dismiss();
                if(events.size()<1){
                    showDialog("Empty","No Event Found | Create New Event");
                }
                else
                {
                    eventsadapter adapter=new eventsadapter(allevents.this,events);
                    events_grid.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {
                progressDialog.dismiss();
                showDialog("Error","Something Went Wrong \n Cause : "+databaseError.getMessage());
            }
        });
    }

    @Override
    public void onBackPressed(){
        finish();
        super.onBackPressed();
    }

    public  void showDialog(String Title, String Message){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        View child = getLayoutInflater().inflate(R.layout.dialog_custom, null);
        TextView title=child.findViewById(R.id.txtView_title);
        TextView message=child.findViewById(R.id.txtView_message);
        Button btn_action=child.findViewById(R.id.btn_ok);
        title.setText(Title);
        message.setText(Message);
        btn_action.setText("Ok");
        builder1.setView(child);
        builder1.setCancelable(true);
        final AlertDialog dialog = builder1.create();
        dialog.show();
        btn_action.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                onBackPressed();
            }
        });
    }
}
